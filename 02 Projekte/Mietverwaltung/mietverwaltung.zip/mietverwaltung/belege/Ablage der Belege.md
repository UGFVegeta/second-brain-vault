# Belege

Hier kommen Rechnungen und Belege hinein, sortiert nach Objekt und Jahr:

```
belege\
  Gartenstr. 12\
    2026\
      Heizungswartung Rechnung.pdf
      Grundsteuer Q3.pdf
  Lindenweg 4\
    2026\
```

Mehr Struktur braucht es nicht. Eine eigene Dokumentenverwaltung mit Server
und Datenbank wäre für diesen Zweck überzogen; ein klar benannter Ordner tut
dasselbe und überlebt jeden Softwarewechsel.

Claude kann die Belege lesen und Betrag, Datum und Kategorie in die
Ausgabenübersicht übernehmen. Sag dafür: „Ordne die neuen Belege zu."

Die Zuordnung passiert dann, wenn man danach fragt, nicht im Hintergrund.
Belege werden also nicht in dem Moment erfasst, in dem man sie ablegt,
sondern beim nächsten Durchgang.
