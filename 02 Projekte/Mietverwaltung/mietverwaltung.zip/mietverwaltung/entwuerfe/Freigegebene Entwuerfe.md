# Entwürfe

Hier legt Claude fertige Mailentwürfe ab, nachdem sie freigegeben wurden.
Als einfache Textdateien zum Kopieren ins Mailprogramm.

Verschickt wird nichts von hier aus. Das ist Absicht.
